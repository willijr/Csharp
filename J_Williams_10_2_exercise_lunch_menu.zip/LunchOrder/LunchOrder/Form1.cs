using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LunchOrder
{
    public partial class Form1 : Form
    {
        double subtotal;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void radioHamburger_CheckedChanged(object sender, EventArgs e)
        {
            if (radioHamburger.Checked == true)
            {
                radioHamburger.Checked = true;
                radioPizza.Checked = false;
                radioSalad.Checked = false;
                gbxAddOnItems.Text = "Add-on items ($.75/each)";
                checkBoxFirst.Text = "Lettuce, tomato, and onions";
                checkBoxSecond.Text = "Ketchup, mustard, and mayo";
                checkBoxThird.Text = "French fries";
                ClearTotals();
                ClearAddOns();
            }
        }

        private void radioPizza_CheckedChanged(object sender, EventArgs e)
        {
            if (radioPizza.Checked == true)
            {
                radioHamburger.Checked = false;
                radioPizza.Checked = true;
                radioSalad.Checked = false;
                gbxAddOnItems.Text = "Add-on items ($.50/each)";
                checkBoxFirst.Text = "Pepperoni";
                checkBoxSecond.Text = "Sausage";
                checkBoxThird.Text = "Olives";
                ClearTotals();
                ClearAddOns();
            }
        }

        private void radioSalad_CheckedChanged(object sender, EventArgs e)
        {
            if (radioSalad.Checked == true)
            {
                radioHamburger.Checked = false;
                radioPizza.Checked = false;
                radioSalad.Checked = true;
                gbxAddOnItems.Text = "Add-on items ($.25/each)";
                checkBoxFirst.Text = "Croutons";
                checkBoxSecond.Text = "Bacon bits";
                checkBoxThird.Text = "Bread sticks";
                ClearTotals();
                ClearAddOns();
            }
        }

        void ClearTotals()
        {
            lblOrderTotal.Text = "";
            lblSalesTax.Text = "";
            lblSubtotal.Text = "";
            labelName.Text = "";
        }

        void ClearAddOns()
        {
            checkBoxFirst.Checked = false;
            checkBoxSecond.Checked = false;
            checkBoxThird.Checked = false;
        }

        double Subtotal(double mainOrder, double addOn)
        {
            double totalAddOn = 0;
            if (checkBoxFirst.Checked == true)
                totalAddOn = totalAddOn + addOn;
            if (checkBoxSecond.Checked == true)
                totalAddOn = totalAddOn + addOn;
            if (checkBoxThird.Checked == true)
                totalAddOn = totalAddOn + addOn;

            subtotal = mainOrder + totalAddOn;
            lblSubtotal.Text = subtotal.ToString("c");
            return subtotal;
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            if (radioHamburger.Checked == true)
            {
                Subtotal(6.95, .75);
            }

            if (radioPizza.Checked == true)
            {
                Subtotal(5.95, .50);
            }

            if (radioSalad.Checked == true)
            {
                Subtotal(4.95, .25);
            }

            double salesTax = (subtotal * 7.75 / 100);
            lblSalesTax.Text = salesTax.ToString("c");

            double orderTotal = subtotal + salesTax;
            lblOrderTotal.Text = orderTotal.ToString("c");

            labelName.Text = "By: Jeffrey Williams";
        }

        private void checkBoxFirst_CheckedChanged(object sender, EventArgs e)
        {
            ClearTotals();
        }

        private void checkBoxSecond_CheckedChanged_1(object sender, EventArgs e)
        {
            ClearTotals();
        }

        private void checkBoxThird_CheckedChanged_1(object sender, EventArgs e)
        {
            ClearTotals();
        }
    }
}